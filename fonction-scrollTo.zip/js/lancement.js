$(document).ready(function() {

	$.localScroll();	
	
});